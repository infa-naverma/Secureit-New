#Road Map

The tool is in a development phase and below features will be implemented.

* API Automated vulnerability scanning.
* Perform Reconnaissance before scanning.
* Concurrent Scans.
* Vulnerability POC pictures.
* Cloud Security scanning.
* Dashboards
* Easy to installing.


