# Complete guide <small>for Kali</small>

Archery tool fully supported in Kali linux and you can easily install & Configure. Follow the below video guide.

<iframe width="854" height="480" src="https://www.youtube.com/embed/Gb_6WPqUqGQ" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>